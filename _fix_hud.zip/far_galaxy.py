import math
from pathlib import Path
import numpy as np
import moderngl
import glm


class FarGalaxy:
    """
    Genuine far-distance galaxy Level-of-Detail (LOD) representation.
    
    Derived directly from the procedural Milky Way model parameters:
    - Central nuclear bulge with warm golden Population II core
    - 28-degree rotated 3D central bar with boxy/peanut profile
    - 4 asymmetric logarithmic spiral arms with dense OB blue spines and warm envelopes
    - Diffuse older stellar disc with inter-bar resonance cavity
    - Structured dark dust lanes running along inner arm edges and across the bar
    - Localized H-II emission nebulae matching NebulaManager regions exactly
    
    Rendered as a layered 3D volumetric slab on the actual galactic plane
    (transformed by u_model, u_view, u_projection) to provide perspective-correct
    views from face-on, oblique, and edge-on orientations.
    """

    def __init__(self, ctx, base_dir, nebula_mgr=None, res=1024):
        self.ctx = ctx
        self.base_dir = Path(base_dir)
        self.res = res
        self.half_size = 48.0

        # Load dedicated shaders
        with open(self.base_dir / "shaders" / "far_galaxy_vert.glsl", encoding="utf-8") as f:
            vert_code = f.read()
        with open(self.base_dir / "shaders" / "far_galaxy_frag.glsl", encoding="utf-8") as f:
            frag_code = f.read()

        self.program = self.ctx.program(
            vertex_shader=vert_code,
            fragment_shader=frag_code,
        )

        # ------------------------------------------------------------------
        # 1. Precompute Multichannel Galaxy Representation
        # ------------------------------------------------------------------
        stellar_data, dust_neb_data = self._generate_far_textures(nebula_mgr)

        self.stellar_tex = self.ctx.texture((self.res, self.res), 4, data=stellar_data.tobytes(), dtype='f2')
        self.stellar_tex.filter = (self.ctx.LINEAR_MIPMAP_LINEAR, self.ctx.LINEAR)
        self.stellar_tex.build_mipmaps()

        self.dust_nebula_tex = self.ctx.texture((self.res, self.res), 4, data=dust_neb_data.tobytes(), dtype='f2')
        self.dust_nebula_tex.filter = (self.ctx.LINEAR_MIPMAP_LINEAR, self.ctx.LINEAR)
        self.dust_nebula_tex.build_mipmaps()

        # ------------------------------------------------------------------
        # 2. Build 3D Slab Geometry (Layered Horizontal Slices)
        # ------------------------------------------------------------------
        # Slices along Y provide physical vertical thickness for oblique/edge-on views
        # while collapsing smoothly to a single plane for face-on views.
        hs = self.half_size
        self.layers = [
            {"y":  0.00, "weight": 0.36},
            {"y":  0.28, "weight": 0.22},
            {"y": -0.28, "weight": 0.22},
            {"y":  0.62, "weight": 0.10},
            {"y": -0.62, "weight": 0.10},
        ]

        # Base quad data: (x, y, z, u, v)
        quad_verts = []
        for l in self.layers:
            y = l["y"]
            # 2 triangles (6 vertices) per layer
            # Triangle 1
            quad_verts.extend([-hs, y, -hs, 0.0, 0.0])
            quad_verts.extend([ hs, y, -hs, 1.0, 0.0])
            quad_verts.extend([-hs, y,  hs, 0.0, 1.0])
            # Triangle 2
            quad_verts.extend([-hs, y,  hs, 0.0, 1.0])
            quad_verts.extend([ hs, y, -hs, 1.0, 0.0])
            quad_verts.extend([ hs, y,  hs, 1.0, 1.0])

        self.vbo = self.ctx.buffer(np.array(quad_verts, dtype='f4').tobytes())
        self.vao = self.ctx.vertex_array(
            self.program,
            [(self.vbo, '3f 2f', 'in_position', 'in_texcoord')]
        )

    def _generate_far_textures(self, nebula_mgr):
        """Precomputes stellar radiance and dust/nebula multichannel textures."""
        res = self.res
        hs = self.half_size
        x = np.linspace(-hs, hs, res, dtype=np.float32)
        z = np.linspace(-hs, hs, res, dtype=np.float32)
        X, Z = np.meshgrid(x, z)
        R = np.sqrt(X * X + Z * Z)
        Theta = np.arctan2(Z, X)

        # ----------------------------------------------------------
        # A. Central Bulge (Warm Golden/Orange Core)
        # ----------------------------------------------------------
        bulge_core = np.exp(-R / 0.38) * 8.5
        bulge_halo = np.exp(-R / 1.15) * 2.8
        bulge_total = bulge_core + bulge_halo
        col_bulge = np.array([1.25, 0.82, 0.45], dtype=np.float32)

        # ----------------------------------------------------------
        # B. Central Bar (28 deg tilt, Ferrers major-axis profile)
        # ----------------------------------------------------------
        BAR_LENGTH = 7.2
        BAR_ANGLE_Z = 0.488  # 28 degrees relative to Z
        u = X * np.cos(BAR_ANGLE_Z) + Z * np.sin(BAR_ANGLE_Z)
        v = -X * np.sin(BAR_ANGLE_Z) + Z * np.cos(BAR_ANGLE_Z)

        u_norm = np.clip(np.abs(u) / BAR_LENGTH, 0.0, 1.0)
        # Transverse width with peanut tapering
        w_v = 1.02 * np.sqrt(np.maximum(0.01, 1.0 - 0.75 * u_norm**2))
        v_norm = np.abs(v) / w_v
        bar_prof = np.exp(-0.5 * v_norm**2) * np.sqrt(np.maximum(0.0, 1.0 - u_norm**2)) * np.exp(-np.abs(u) / 4.8) * 3.4
        col_bar = np.array([1.18, 0.90, 0.62], dtype=np.float32)

        # ----------------------------------------------------------
        # C. 4 Spiral Arms + Dense OB Spines + Warm Envelopes
        # ----------------------------------------------------------
        ARM_COUNT = 4
        SPIRAL_TIGHTNESS = 2.5
        INNER_ARM_R = 3.5
        bar_angle_polar = math.pi / 2.0 - 0.488
        arm_base_offset = bar_angle_polar - SPIRAL_TIGHTNESS * math.log(7.0 / INNER_ARM_R)

        arm_spine = arm_base_offset + SPIRAL_TIGHTNESS * np.log(np.maximum(R, INNER_ARM_R) / INNER_ARM_R)
        arm_weights = [0.31, 0.20, 0.30, 0.19]

        dense_spine_total = np.zeros_like(R)
        broad_env_total = np.zeros_like(R)
        dust_lanes_total = np.zeros_like(R)

        r_gate = (R >= INNER_ARM_R) & (R <= 46.0)
        outer_fade = np.clip((46.0 - R) / 8.0, 0.0, 1.0)

        for i in range(ARM_COUNT):
            base_th = float(i) * (2.0 * math.pi / ARM_COUNT)
            psi = (Theta - (base_th + arm_spine) + math.pi) % (2.0 * math.pi) - math.pi

            # Dense star-forming spine (young blue OB stars)
            w_spine = 0.11 + 0.08 * (R / 45.0)
            s_norm = (R - INNER_ARM_R) / 41.5
            knot = 0.15 * np.sin(2.0 * math.pi * 3.2 * s_norm + i * 1.57) + 0.08 * np.sin(2.0 * math.pi * 6.5 * s_norm)
            spine_d = np.exp(-0.5 * ((psi - knot) / w_spine)**2) * arm_weights[i] * 2.2

            # Broad stellar envelope
            w_env = 0.24 + 0.16 * (R / 45.0)
            env_d = np.exp(-0.5 * (psi / w_env)**2) * arm_weights[i] * 1.2

            # Dark dust lane: runs on the inner leading edge (psi ~ -0.12)
            w_dust = 0.08 + 0.05 * (R / 45.0)
            dust_d = np.exp(-0.5 * ((psi + 0.12) / w_dust)**2) * (arm_weights[i] / 0.31) * 1.8

            dense_spine_total += spine_d * r_gate * outer_fade
            broad_env_total += env_d * r_gate * outer_fade
            dust_lanes_total += dust_d * r_gate * outer_fade

        col_ob_spine = np.array([0.76, 0.90, 1.25], dtype=np.float32)
        col_broad_env = np.array([1.08, 0.98, 0.88], dtype=np.float32)

        # ----------------------------------------------------------
        # D. Diffuse Inter-Arm Disk + Resonance Depletion
        # ----------------------------------------------------------
        disk_profile = np.exp(-R / 8.0) * outer_fade * 0.85
        # Inter-bar resonance cavity depletion inside r < 7.5
        minor_prox = np.abs(np.sin(Theta - bar_angle_polar))
        depletion = np.where(R < 7.5, (1.0 - np.clip((R - 3.0) / 4.5, 0.0, 1.0)) * (0.85 * minor_prox), 0.0)
        diffuse_disk = np.maximum(0.0, disk_profile * (1.0 - depletion))
        col_diffuse = np.array([1.02, 0.86, 0.65], dtype=np.float32)

        # ----------------------------------------------------------
        # E. Central Bar Leading-Edge Dust Lanes
        # ----------------------------------------------------------
        v_target = np.sign(u) * 0.38
        dv = np.abs(v - v_target)
        bar_dust = np.exp(-dv * dv / 0.035) * np.clip((np.abs(u) - 0.8) / 1.0, 0.0, 1.0) * (1.0 - np.clip((np.abs(u) - 6.5) / 1.0, 0.0, 1.0)) * 2.2
        dust_lanes_total = np.maximum(dust_lanes_total, bar_dust)

        # Assemble Stellar Texture (RGBA16F)
        stellar_img = np.zeros((res, res, 4), dtype=np.float32)
        for c in range(3):
            stellar_img[:, :, c] = (
                bulge_total * col_bulge[c] +
                bar_prof * col_bar[c] +
                dense_spine_total * col_ob_spine[c] +
                broad_env_total * col_broad_env[c] +
                diffuse_disk * col_diffuse[c]
            )

        # Density / coverage alpha
        stellar_density = bulge_total + bar_prof + dense_spine_total + broad_env_total + diffuse_disk
        stellar_img[:, :, 3] = np.clip(stellar_density * 0.45, 0.0, 1.0)

        # Assemble Dust & Nebula Texture (RGBA16F)
        # R: Dust optical depth
        # G, B, A: Localized Nebula emission RGB
        dust_neb_img = np.zeros((res, res, 4), dtype=np.float32)
        dust_neb_img[:, :, 0] = dust_lanes_total

        if nebula_mgr is not None and hasattr(nebula_mgr, 'nebulae_data'):
            for n in nebula_mgr.nebulae_data:
                nx, ny, nz, nr = n['position']
                col = np.array(n['color'][:3], dtype=np.float32) * n['color'][3]
                ix0 = max(0, int((nx - 2.5 * nr + hs) / (2.0 * hs) * res))
                ix1 = min(res, int((nx + 2.5 * nr + hs) / (2.0 * hs) * res) + 1)
                iz0 = max(0, int((nz - 2.5 * nr + hs) / (2.0 * hs) * res))
                iz1 = min(res, int((nz + 2.5 * nr + hs) / (2.0 * hs) * res) + 1)
                if ix1 > ix0 and iz1 > iz0:
                    subX = X[iz0:iz1, ix0:ix1]
                    subZ = Z[iz0:iz1, ix0:ix1]
                    d2 = (subX - nx)**2 + (subZ - nz)**2
                    mask = np.exp(-0.5 * d2 / (nr * 0.55)**2)
                    for c in range(3):
                        dust_neb_img[iz0:iz1, ix0:ix1, c + 1] += mask * col[c]

        return stellar_img.astype(np.float16), dust_neb_img.astype(np.float16)

    def render(self, camera, aspect_ratio, visibility, rotation_angle):
        """Renders the far galaxy representation on the galactic plane in 3D perspective."""
        if visibility <= 0.001:
            return

        self.ctx.enable(moderngl.BLEND)
        self.ctx.blend_func = moderngl.ONE, moderngl.SRC_ALPHA

        # Bind precomputed maps
        self.stellar_tex.use(location=0)
        self.dust_nebula_tex.use(location=1)

        if "u_stellarMap" in self.program:
            self.program["u_stellarMap"].value = 0
        if "u_dustNebulaMap" in self.program:
            self.program["u_dustNebulaMap"].value = 1
        if "u_visibility" in self.program:
            self.program["u_visibility"].value = visibility

        if "u_view" in self.program:
            self.program["u_view"].write(camera.get_view_matrix())
        if "u_projection" in self.program:
            self.program["u_projection"].write(camera.get_projection_matrix(aspect_ratio))

        # Rotate strictly in synchrony with the galaxy pattern
        model = glm.rotate(glm.mat4(1.0), rotation_angle, glm.vec3(0.0, 1.0, 0.0))
        if "u_model" in self.program:
            self.program["u_model"].write(model)

        # Render layered slices (6 vertices per slice)
        num_layers = len(self.layers)
        for i in range(num_layers):
            if "u_layerWeight" in self.program:
                self.program["u_layerWeight"].value = self.layers[i]["weight"]
            self.vao.render(mode=moderngl.TRIANGLES, vertices=6, first=i * 6)

    def render_depth(self, camera, aspect_ratio, rotation_angle):
        """Writes central galactic plane depth for dust and nebula occlusion."""
        self.ctx.enable(moderngl.DEPTH_TEST)
        self.ctx.depth_mask = True

        if "u_view" in self.program:
            self.program["u_view"].write(camera.get_view_matrix())
        if "u_projection" in self.program:
            self.program["u_projection"].write(camera.get_projection_matrix(aspect_ratio))
        model = glm.rotate(glm.mat4(1.0), rotation_angle, glm.vec3(0.0, 1.0, 0.0))
        if "u_model" in self.program:
            self.program["u_model"].write(model)
        if "u_visibility" in self.program:
            self.program["u_visibility"].value = 1.0
        if "u_layerWeight" in self.program:
            self.program["u_layerWeight"].value = 1.0

        self.stellar_tex.use(location=0)
        self.dust_nebula_tex.use(location=1)
        self.vao.render(mode=moderngl.TRIANGLES, vertices=6, first=0)

    def release(self):
        """Release GPU resources."""
        self.vbo.release()
        self.vao.release()
        self.stellar_tex.release()
        self.dust_nebula_tex.release()
        self.program.release()
