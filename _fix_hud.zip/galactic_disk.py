import math
from pathlib import Path
import numpy as np
import moderngl
import glm


class GalacticDisk:
    """
    Stellar disk of the Milky Way simulation with time-dependent, radius-dependent
    differential galactic rotation and persistent Lin-Shu density wave kinematics.
    
    Individual stars orbit with differential angular velocity:
        omega(r) = v_flat / sqrt(r*r + r_core*r_core)
    approaching flat tangential velocity v_flat at large radii.
    
    The central bar and large-scale 4-arm spiral density wave rotate coherently at
    pattern speed Omega_p (corotation near the bar tips r ~ 7.5).
    Stars drift continuously relative to the spiral pattern without winding up or
    blurring into concentric rings.
    """

    def __init__(self, ctx, base_dir, nebula_stars=None, seed=42, diagnostic_mode=False):
        self.ctx = ctx
        self.base_dir = Path(base_dir)
        self.num_stars = 2000000
        self.seed = seed
        self.diagnostic_mode = diagnostic_mode

        # Differential rotation and spiral density wave parameters
        self.v_flat = 0.85
        self.r_core = 3.2
        self.r_cr = 7.5
        self.pattern_speed = self.v_flat / math.sqrt(self.r_cr ** 2 + self.r_core ** 2)

        self.spiral_tightness = 2.5
        self.inner_arm_radius = 3.5
        self.outer_radius = 45.0
        self.disk_scale = 8.0

        # In-plane bar orientation in polar coordinates (matches GalacticBar 28 deg tilt)
        self.bar_angle_polar = math.pi / 2.0 - 0.488  # ~ 1.0828 rad
        self.arm_base_offset = self.bar_angle_polar - self.spiral_tightness * math.log(7.0 / self.inner_arm_radius)
        self.compression = 0.22

        # Load dedicated disk shaders supporting GPU differential rotation
        with open(self.base_dir / "shaders" / "disk_vert.glsl", encoding="utf-8") as f:
            vert_code = f.read()
        with open(self.base_dir / "shaders" / "bulge_frag.glsl", encoding="utf-8") as f:
            frag_code = f.read()

        self.program = self.ctx.program(
            vertex_shader=vert_code,
            fragment_shader=frag_code,
        )

        rng = np.random.default_rng(self.seed)

        def smoothstep_np(e0, e1, x):
            t = np.clip((x - e0) / (e1 - e0), 0.0, 1.0)
            return t * t * (3.0 - 2.0 * t)

        # ==========================================================
        # 1. Dual-Component Stellar Disk (Structured Arms + Diffuse Disc)
        # ==========================================================
        # 68% Arm stars concentrated along the 4 spiral arms
        # 32% Diffuse inter-arm background stars
        n_arm = int(self.num_stars * 0.68)
        n_diffuse = self.num_stars - n_arm

        # --- A. Arm Population (Structured, Clumpy, Layered) ---
        # Sample radii with exponential disc falloff
        r_arm = rng.gamma(shape=2.2, scale=self.disk_scale, size=int(n_arm * 1.35))
        r_arm = r_arm[(r_arm >= self.inner_arm_radius) & (r_arm <= self.outer_radius)]
        # Outer disk soft fade: reject stars past 38 with probability smoothstep(38, 46)
        fade_prob = 1.0 - smoothstep_np(38.0, 46.0, r_arm)
        r_arm = r_arm[rng.random(len(r_arm)) < fade_prob][:n_arm]
        while len(r_arm) < n_arm:
            extra = rng.gamma(shape=2.2, scale=self.disk_scale, size=n_arm - len(r_arm))
            extra = extra[(extra >= self.inner_arm_radius) & (extra <= self.outer_radius)]
            fade = 1.0 - smoothstep_np(38.0, 46.0, extra)
            r_arm = np.concatenate((r_arm, extra[rng.random(len(extra)) < fade]))
        r_arm = r_arm[:n_arm]

        # 4 Spiral arms with realistic astrophysical asymmetry:
        # Arm 0 (Scutum-Centaurus, major): 31%
        # Arm 1 (Sagittarius, minor): 20%
        # Arm 2 (Perseus, major): 30%
        # Arm 3 (Norma, minor): 19%
        arm_indices = rng.choice(4, size=n_arm, p=[0.31, 0.20, 0.30, 0.19])
        arm_base_angles = arm_indices * (2.0 * math.pi / 4.0)

        # Logarithmic spiral spine
        arm_spine_arm = self.arm_base_offset + self.spiral_tightness * np.log(r_arm / self.inner_arm_radius)
        ideal_theta_arm = arm_base_angles + arm_spine_arm

        # Along-arm density wave modulation (star-forming knots, clumps & gaps):
        s_norm = (r_arm - self.inner_arm_radius) / (self.outer_radius - self.inner_arm_radius)
        phi_arm = arm_indices * 1.5708
        knot_offset = 0.15 * np.sin(2.0 * math.pi * 3.2 * s_norm + phi_arm) + 0.08 * np.sin(2.0 * math.pi * 6.5 * s_norm)

        # Azimuthal Gaussian width: two-tier astrophysical arm structure
        # Tier 1 (55%): dense star-forming spine, knots and bright clusters
        # Tier 2 (45%): broad stellar envelope connecting smoothly into the disk
        is_dense_spine = rng.random(n_arm) < 0.55
        sigma_theta_dense = 0.11 + 0.08 * (r_arm / self.outer_radius)
        sigma_theta_broad = 0.24 + 0.16 * (r_arm / self.outer_radius)
        sigma_theta = np.where(is_dense_spine, sigma_theta_dense, sigma_theta_broad)

        theta_arm = ideal_theta_arm + rng.normal(0.0, sigma_theta, size=n_arm) + np.where(is_dense_spine, knot_offset, knot_offset * 0.4)

        # Arm thickness: young stars are in a very thin disk
        thickness_arm = 0.12 + 0.14 * (r_arm / self.outer_radius)
        y_arm = rng.normal(0.0, thickness_arm, size=n_arm)

        # --- B. Diffuse Inter-Arm Population (Background Glow) ---
        r_diff = rng.gamma(shape=2.0, scale=self.disk_scale, size=int(n_diffuse * 1.35))
        r_diff = r_diff[(r_diff >= self.inner_arm_radius) & (r_diff <= self.outer_radius)]
        fade_diff = 1.0 - smoothstep_np(38.0, 46.0, r_diff)
        r_diff = r_diff[rng.random(len(r_diff)) < fade_diff][:n_diffuse]
        while len(r_diff) < n_diffuse:
            extra = rng.gamma(shape=2.0, scale=self.disk_scale, size=n_diffuse - len(r_diff))
            extra = extra[(extra >= self.inner_arm_radius) & (extra <= self.outer_radius)]
            fade = 1.0 - smoothstep_np(38.0, 46.0, extra)
            r_diff = np.concatenate((r_diff, extra[rng.random(len(extra)) < fade]))
        r_diff = r_diff[:n_diffuse]

        theta_diff = rng.uniform(0.0, 2.0 * math.pi, size=n_diffuse)
        
        # Inter-bar resonance cavity depletion inside r < 7.5 to keep 3D bar prominent
        minor_axis_prox = np.abs(np.sin(theta_diff - self.bar_angle_polar))
        depletion = np.where(r_diff < 7.5, (1.0 - smoothstep_np(3.0, 7.5, r_diff)) * (0.85 * minor_axis_prox), 0.0)
        rejected = rng.random(n_diffuse) < depletion
        attempts = 0
        while np.any(rejected) and attempts < 10:
            n_rej = np.sum(rejected)
            new_th = rng.uniform(0.0, 2.0 * math.pi, size=n_rej)
            new_prox = np.abs(np.sin(new_th - self.bar_angle_polar))
            new_dep = np.where(r_diff[rejected] < 7.5, (1.0 - smoothstep_np(3.0, 7.5, r_diff[rejected])) * (0.85 * new_prox), 0.0)
            acc = rng.random(n_rej) >= new_dep
            if np.any(acc):
                sub_indices = np.where(rejected)[0][acc]
                theta_diff[sub_indices] = new_th[acc]
            curr_prox = np.abs(np.sin(theta_diff - self.bar_angle_polar))
            curr_dep = np.where(r_diff < 7.5, (1.0 - smoothstep_np(3.0, 7.5, r_diff)) * (0.85 * curr_prox), 0.0)
            rejected = rng.random(n_diffuse) < curr_dep
            attempts += 1

        # Diffuse disk thickness: thicker older population with radial flare
        thickness_diff = 0.25 + 0.30 * (r_diff / self.outer_radius)
        y_diff = rng.normal(0.0, thickness_diff, size=n_diffuse)

        # Combine components
        radius = np.concatenate((r_arm, r_diff)).astype('f4')
        theta = np.concatenate((theta_arm, theta_diff)).astype('f4')
        y = np.concatenate((y_arm, y_diff)).astype('f4')

        x = radius * np.cos(theta)
        z = radius * np.sin(theta)
        positions = np.column_stack((x, y, z)).astype('f4')

        # 4. Continuous Arm-Proximity & Astrophysical Stellar Population
        arm_spine_total = self.arm_base_offset + self.spiral_tightness * np.log(radius / self.inner_arm_radius)
        psi = 4.0 * (theta - arm_spine_total)
        psi_wrap = (psi + math.pi) % (2.0 * math.pi) - math.pi
        arm_factor = 0.5 + 0.5 * np.cos(psi_wrap)
        is_arm_star = np.arange(self.num_stars) < n_arm
        arm_factor = np.where(is_arm_star, np.clip(arm_factor * 1.25, 0.0, 1.0), arm_factor * 0.45)

        from stellar_population import generate_stellar_population
        colors, sizes, brightness = generate_stellar_population(
            self.num_stars,
            population_type='disk',
            rng=rng,
            arm_factor=arm_factor,
            radius=radius,
            diagnostic_mode=self.diagnostic_mode
        )

        star_data = np.column_stack((positions, colors, sizes, brightness)).astype('f4')

        self.vbo = self.ctx.buffer(star_data.tobytes())
        self.vao = self.ctx.vertex_array(
            self.program,
            [(self.vbo, '3f 3f 1f 1f', 'in_position', 'in_color', 'in_size', 'in_brightness')]
        )

        # Nebula-associated stars: rotate rigidly at pattern speed with the nebulae
        # so differential shearing never separates young stellar clusters from their parent clouds.
        self.nebula_vao = None
        if nebula_stars is not None and len(nebula_stars) > 0:
            with open(self.base_dir / "shaders" / "bulge_vert.glsl", encoding="utf-8") as f:
                neb_vert_code = f.read()
            self.nebula_program = self.ctx.program(
                vertex_shader=neb_vert_code,
                fragment_shader=frag_code,
            )
            self.nebula_vbo = self.ctx.buffer(np.ascontiguousarray(nebula_stars, dtype='f4').tobytes())
            self.nebula_vao = self.ctx.vertex_array(
                self.nebula_program,
                [(self.nebula_vbo, '3f 3f 1f 1f', 'in_position', 'in_color', 'in_size', 'in_brightness')]
            )
            self.num_stars += len(nebula_stars)

    def render(self, camera, aspect_ratio, visibility, rotation_angle, sim_time=0.0):
        if visibility <= 0.001:
            return

        self.ctx.enable(moderngl.PROGRAM_POINT_SIZE)
        self.ctx.enable(moderngl.BLEND)
        self.ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE

        if "u_visibility" in self.program:
            self.program["u_visibility"].value = visibility

        if "u_view" in self.program:
            self.program["u_view"].write(camera.get_view_matrix())
        if "u_projection" in self.program:
            self.program["u_projection"].write(camera.get_projection_matrix(aspect_ratio))
        model = glm.rotate(glm.mat4(1.0), rotation_angle, glm.vec3(0.0, 1.0, 0.0))
        if "u_model" in self.program:
            self.program["u_model"].write(model)

        # GPU-side differential rotation and density wave uniforms
        if "u_simTime" in self.program:
            self.program["u_simTime"].value = sim_time
        if "u_vFlat" in self.program:
            self.program["u_vFlat"].value = self.v_flat
        if "u_rCore" in self.program:
            self.program["u_rCore"].value = self.r_core
        if "u_patternSpeed" in self.program:
            self.program["u_patternSpeed"].value = self.pattern_speed
        if "u_armTightness" in self.program:
            self.program["u_armTightness"].value = self.spiral_tightness
        if "u_armOffset" in self.program:
            self.program["u_armOffset"].value = self.arm_base_offset
        if "u_innerArmR" in self.program:
            self.program["u_innerArmR"].value = self.inner_arm_radius
        if "u_compression" in self.program:
            self.program["u_compression"].value = self.compression

        self.vao.render(moderngl.POINTS)

        # Render nebula-associated stars with coherent pattern speed
        if self.nebula_vao is not None:
            if "u_visibility" in self.nebula_program:
                self.nebula_program["u_visibility"].value = visibility
            if "u_view" in self.nebula_program:
                self.nebula_program["u_view"].write(camera.get_view_matrix())
            if "u_projection" in self.nebula_program:
                self.nebula_program["u_projection"].write(camera.get_projection_matrix(aspect_ratio))
            if "u_model" in self.nebula_program:
                self.nebula_program["u_model"].write(model)
            self.nebula_vao.render(moderngl.POINTS)
